<?php
/**
 * api/game_sync.php
 * Returns moves since a given move_number for an online game.
 * Also returns game status and player info.
 */
require_once __DIR__ . '/../config/app.php';
header('Content-Type: application/json');

$roomCode = trim($_GET['room_code'] ?? '');
$since    = (int)($_GET['since'] ?? 0); // last known move_number

if (empty($roomCode)) jsonError('Missing room_code');

$game = Database::queryOne("SELECT * FROM games WHERE room_code = ?", [$roomCode]);
if (!$game) jsonError('Game not found', 404);

// Get moves since last known
$moves = Database::query(
    "SELECT move_data, move_number, player_id
     FROM moves
     WHERE game_id = ? AND move_number > ?
     ORDER BY move_number ASC",
    [$game['id'], $since]
);

$parsedMoves = array_map(function($m) {
    return [
        'move'        => json_decode($m['move_data'], true),
        'move_number' => (int)$m['move_number'],
        'player_id'   => (int)$m['player_id'],
    ];
}, $moves);

// Total move count determines whose turn it is
$totalMoves  = (int)Database::queryOne("SELECT COUNT(*) as c FROM moves WHERE game_id=?", [$game['id']])['c'];
$currentTurn = ($totalMoves % 2 === 0) ? 1 : 2; // P1 on even, P2 on odd

jsonSuccess([
    'status'      => $game['status'],
    'player1_id'  => (int)$game['player1_id'],
    'player2_id'  => $game['player2_id'] ? (int)$game['player2_id'] : null,
    'moves'       => $parsedMoves,
    'total_moves' => $totalMoves,
    'current_turn'=> $currentTurn, // 1 or 2
]);
